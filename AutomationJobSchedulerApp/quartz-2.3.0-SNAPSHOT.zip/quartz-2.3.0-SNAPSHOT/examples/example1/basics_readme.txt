Example 1
=========

Overview:
=========
This example will demonstrate how to quickly get quartz up 
and running and how to schedule a simple job.


Running the Example:
====================
1. Windows users - Modify the example1.bat file (if necessary) 
to set your JAVA_HOME.  Run example1.bat

2. UNIX/Linux users - Modify the example1.sh file (if necessary)
to set your JAVA_HOME.  Execute example1.sh


Configuration Files:
====================
1.  You can decide to specify a log4j.properties file to
control logging output (optional)
